const sodium = require('sodium-native');

// Create buffers to hold the keypair
const identityPublicKey = Buffer.alloc(sodium.crypto_box_PUBLICKEYBYTES);
const identitySecretKey = Buffer.alloc(sodium.crypto_box_SECRETKEYBYTES);

// Generate an identity key pair
sodium.crypto_box_keypair(identityPublicKey, identitySecretKey);

// Create buffers for the pre-key pair
const preKeyPublicKey = Buffer.alloc(sodium.crypto_box_PUBLICKEYBYTES);
const preKeySecretKey = Buffer.alloc(sodium.crypto_box_SECRETKEYBYTES);

// Generate a pre-key pair
sodium.crypto_box_keypair(preKeyPublicKey, preKeySecretKey);

console.log('Identity Key Pair:');
console.log({
  publicKey: identityPublicKey.toString('hex'),
  privateKey: identitySecretKey.toString('hex'),
});

console.log('\nPre-Key Pair:');
console.log({
  publicKey: preKeyPublicKey.toString('hex'),
  privateKey: preKeySecretKey.toString('hex'),
});
