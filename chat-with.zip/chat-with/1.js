const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Serve files from the 'uploads' directory
app.use('/uploads', express.static('uploads'));

const sessions = {};

// Function to generate a session key
function generateSessionKey() {
  return Math.random().toString(36).substr(2, 9);
}

// Function to create private key file
function createPrivateKeyFile(sessionKey) {
  const privateKeyPath = `./private-keys/${sessionKey}.pem`;
  fs.writeFileSync(privateKeyPath, sessionKey);
  return privateKeyPath;
}

// Socket.IO connection event
io.on('connection', (socket) => {
  console.log('User connected');

  // Generate a session key for the user
  const sessionKey = generateSessionKey();
  const privateKeyPath = createPrivateKeyFile(sessionKey);
  sessions[socket.id] = { sessionKey, privateKeyPath };

  // Send the session key to the user
  socket.emit('sessionKey', sessionKey);

  // Listen for chat messages
  socket.on('chat message', (msg) => {
    io.emit('chat message', `${socket.id}: ${msg}`);
  });

  // Listen for file sharing
  socket.on('file', (data) => {
    const { filename, content } = data;
    const filepath = `./uploads/${filename}`;
    fs.writeFileSync(filepath, Buffer.from(content, 'base64'));
    io.emit('file', { sender: socket.id, filename });
  });

  // Listen for disconnection
  socket.on('disconnect', () => {
    console.log('User disconnected');
    delete sessions[socket.id];
  });
});

// Download route to handle file downloads
app.get('/download/:filename', (req, res) => {
  const filename = req.params.filename;
  const filepath = `./uploads/${filename}`;

  // Send the file for download
  res.download(filepath, filename, (err) => {
    if (err) {
      console.error('Error downloading file:', err);
      res.status(500).end();
    }
  });
});

server.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});
