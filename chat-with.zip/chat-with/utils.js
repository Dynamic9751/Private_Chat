const fs = require('fs');
const path = require('path');

// Function to create the private key file for a session
function createPrivateKeyFile(sessionKey) {
  const privateKeyPath = path.join(__dirname, 'private-keys', `${sessionKey}.pem`);

  // Create the directory if it doesn't exist
  const privateKeyDir = path.dirname(privateKeyPath);
  if (!fs.existsSync(privateKeyDir)) {
    fs.mkdirSync(privateKeyDir, { recursive: true });
  }

  fs.writeFileSync(privateKeyPath, ''); // Create an empty file for now
  return privateKeyPath;
}

module.exports = {
  createPrivateKeyFile,
};
