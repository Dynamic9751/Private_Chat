import axios from 'axios';

axios.defaults.withCredentials = true; // Set Axios configuration

export default axios;
